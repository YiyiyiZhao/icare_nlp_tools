from icare_nlp.task_disp_intent import TaskDisp

task_disp=TaskDisp()
task_disp.disp_start()