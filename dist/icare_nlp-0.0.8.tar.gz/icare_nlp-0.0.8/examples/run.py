from icare_nlp.task_disp import TaskDisp

task_disp=TaskDisp()
task_disp.disp_start()