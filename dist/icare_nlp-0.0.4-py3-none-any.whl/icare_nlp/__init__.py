print("Initializing ICARE NLP Tools package...")
